import pandas as pd
import numpy as np
import os
from sklearn.utils import shuffle

folder_names = os.listdir('./')
for i in folder_names:
    X = []
    y = []
    if i =='Train' or i == 'Validation' or i =='Test':
        sub_folder_names = os.listdir('./'+i+'/')
        for j in sub_folder_names:
            if j != ".DS_Store":
                images = os.listdir('./'+i+'/'+j+'/')
                X = X+images
                y = y + [j[-1]] * len(images)

        X, y = shuffle(X, y, random_state=0)
        dict = {'Image': X, 'Class': y}
        df = pd.DataFrame(dict)
        df.to_csv(i+'.csv')
